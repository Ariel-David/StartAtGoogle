package startAtGoogle.LambdasAndStreams.exercise;

import java.util.concurrent.ThreadLocalRandom;

public enum Type {
    MIlK,SHAMPO,IPHONE,BAG
}
