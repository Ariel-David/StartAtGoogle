package startAtGoogle.classesAndInterfaces.exercise2.Farm;

import java.util.Random;

public class Farmer {
    Farm farm = new Farm();
    public void move(Animal a) {
        a.move();
    }

    public Animal requestAnAnimal(){
        Animal a = farm.provideAnimal();
        return a;
    }
}
