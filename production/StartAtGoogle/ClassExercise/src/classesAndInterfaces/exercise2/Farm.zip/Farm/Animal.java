package startAtGoogle.classesAndInterfaces.exercise2.Farm;

public interface Animal {

    public Animal mate(Animal partner);

    public void move();


}
